


c= (input('Enter 1st name: '))
d = (input('Enter 2nd name: '))

print(f'hello {c} {d}!welcome to python program')

