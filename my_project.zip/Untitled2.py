def difference(c, d):
    return (c - d)


c= int(input('Enter 1st number: '))
d = int(input('Enter 2nd number: '))

print(f'difference of {c} and {d} is {difference(c, d)}')

