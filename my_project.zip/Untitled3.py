def multiply(e,f):
    return (e*f)
    
e=int(input('enter first num:'))
f=int(input('enter first num:'))

print(f'multiplication of e and f is {multiply(e,f)}')

